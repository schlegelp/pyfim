__version__ = "0.11"

from pyfim import config
defaults = config.default_parameters

from pyfim.core import Experiment, Collection